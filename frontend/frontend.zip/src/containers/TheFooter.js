import React from "react";
import { CFooter } from "@coreui/react";

const TheFooter = () => {
  let year = new Date();

  return (
    <CFooter fixed={false}>
     
    </CFooter>
  );
};

export default React.memo(TheFooter);
