import React from 'react'
import Calender from '../../../components/dashboard/SchoolCalender'

function ViewCalendar() {
    return (
        <div>
            <Calender />
        </div>
    )
}

export default ViewCalendar
