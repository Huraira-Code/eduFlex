import React from "react";

function PaymentsReceipt() {
  return <div>payment</div>;
}

export default PaymentsReceipt;
