import React from "react";

function Store() {
  return <div>Store</div>;
}

export default Store;
